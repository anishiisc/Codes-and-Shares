#---------------------------------
# Python Module 5 :  Numpy 
# -------------------------------

#---------------------------------------------
# Creating Arrays - from lists 
#---------------------------------------------
from numpy import *
# Single dimensional array 
array_data1 = [1.4, 7, 8, 12.3]
array1 = array(array_data1)
print("Array 1 : ",array1)
#
# Multi dimensional array 
#
array_data2 = [[1, 2, 3, 4], [5, 6, 7, 8]]
array2 = array(array_data2)
print("Array 2: ", array2)

# Check the Dimension of the array 
print("Dimension of array2 is ",array2.ndim)

# Check the Size of Array 
print("Shape of array2 is ",array2.shape)

# Create and array of zeros 
Zero_Array = zeros((3, 6))
print("Zero Array",Zero_Array)

# Check Data Type of Array 
array_data1 = [1,2,3,4]
Array1 = array(array_data1)
print("data type of Array1 is : ",Array1.dtype)

# Convert numeric data as  strings to float 
# Create a string array 
num_strings = array(['1.25', '-9.6', '42'])
# Check data type of array 
print("data type of num_strings  is : ",num_strings.dtype)
# Typecast to float 
float_array = num_strings.astype(float64)
# Check data type of float array 
print("data type of float_array  is : ",float_array.dtype)


#-------------------------------------------------------------------
# Arrays and Scalars 
#-------------------------------------------------------------------
# Notes:1)  Operations between Arrays of same size happens element wise 
# Notes:2)  Operations with Arrays and Scalars will propagate to each element 

#--------------------
# ELement wise array multiplication 
#--------------------
arr1 = array([[1,2,3],[4,5,6]])
arr2 = arr1*arr1 
print("Original Array ",arr1)
print("Element wise sq of arr1 is : ",arr2)
arr3 = arr1*2
print("Double array element wise", arr3)

#--------------------------------------------
# Indexing and slicing of arrays 
#--------------------------------------------
# Define Array of 10 elements 
Arr1 = array(arange(10))
print("Arr1 before manipulation is :",Arr1)
# Choose Index pos 3 to 5 and create a sub array 
# Note the 5th Index position actually does not get selected 
# Note: Only elemenst upto the 5th position get selected 
Sub_Arr1 = Arr1[3:5]
# Display elements of sub array 
print("Sub_Array before change is:",Sub_Arr1)
# Assign a fixed value to sub Array Index Pos 0 
Sub_Arr1[0] = 56
# Display elements of Sub_Arr1
print("Sub Array after change :",Sub_Arr1)
# Display elements of original array 
# Note: change in sub Array caused change in main array 
print("Original Array is",Arr1)
# Assign a element to the entire Sub array 
Sub_Arr1 = 66
# Display Sub Arry 
print("Sub Array after new assign is : ",Sub_Arr1)
# Display main Array 
print("Main Array after new assign is : ", Arr1)

# Slicing multi dimensional Arrays 
# define a 3 by 3 array 
Array1 = array([[1,2,3,4],[5,6,7,8],[9,10,11,12]])
print("Original Array is ", Array1)
Array_Slice1 = Array1[2,:3]
print("Sliced Array is : ",Array_Slice1)


# Boolean Indexing 
#-------------------------------
# Create an Array of names 
Arr_Names = array(['Bob', 'Joe', 'Will', 'Bob', 'Will', 'Joe', 'Joe'])
# Get Array size
Arrsize = Arr_Names.shape
Len1 = Arrsize[0]
# Create a  Vector of random numbers of the same length
# Init a  Vector of size = Len1 
Rand_Set = array(arange(Len1))
# Populate Vectpr with Randome nos from 1 to 10 
for i in range(Len1):
    Rand_Set[i-1] = random.uniform(1,10)
# Display Rand Vector
print("Rand Vector",Rand_Set)
# Get Those Index positions for which name = Bob 
# Use the index set to choose a sub set of Random Numbers 
Match_name_rand = Rand_Set[Arr_Names == 'Bob']
print("Matching Sub set of Rand Num is:",Match_name_rand)

#----------------------------------------------------------
# Array Transpose 
#----------------------------------------------------------
# define A matrix 
A_Mat = array([[1,2,3,4,5],[6,7,8,9,10],[11,12,13,14,15]])
# Print A Matrix 
print("A Matrix",A_Mat)
# Transpose
A_Trans = A_Mat.T
# Print Transpose  of A Matrix 
print("Transposed A Mat",A_Trans)
# Computing At A  
Dot_Prod = dot(A_Trans,A_Mat) 
# Print product 
print("Dot_Product : At A",Dot_Prod)


#----------------------------------------------------------
#   Universal  Array Functions 
# Work elementwise on an array 
# Some examples 
#----------------------------------------------------------
# Unary Function Example
#-----------------------
# Square Root 
#-------------
from numpy import *
Arr = arange(10)
Sqrt_Arr = sqrt(Arr)
print("Sqrt Root values:", )


#--------------------------
# Binary Function example 
#---------------------------

# Create Two Arrays of 10 random numbers each 
x = random.randn(10)
y = random.randn(10)
# Print  both the arrays 
print("X Array is :", x)
print("Y Array is :", y)
# Get the Element wise max, comparing both arrays 
Max_XY = maximum(x,y)
print("The Max element wise is :", Max_XY)


# Conditional logic as Array Operators
# ---
# Define Boolean Array 
Bool_Arr = array([True,False,True,False,True])
X_Arr = array([1,2,3,4,5])
Y_Arr = array([10,20,30,40,50])

Choice = [(X if Z else Y) for X,Y,Z in zip(X_Arr,Y_Arr,Bool_Arr)]
print("Choice: ",Choice)

#---------------------------------
# The where clause in arrays 
#---------------------------------
# Create a 3x3 array of random numbers 
Arr3 = random.randn(3,3)
# Replace pos numbers with +2 and _ve nos with -2 
Arr3_Chg = where(Arr3 > 0, 2, -2)
# Print changed Array 
print("Chg Array is : ", Arr3_Chg)


#-------------------------------------
# Basic Statistical Functions 
#-------------------------------------
Arr_Stat = array([[1,2,3],[4,5,6],[7,8,9]])
# Mean
Arr_Mean = mean(Arr_Stat) 
print("Mean of Array is: ",Arr_Mean)
# Sum 
Arr_Sum = sum(Arr_Stat)
print("Sum of Array is:",Arr_Sum)

#--------------------------------------------
# Stat Operations along a particular direction
#--------------------------------------------

# Get Column means (0th dimension or axis )
Arr_Mean_Cols = Arr_Stat.mean(0)
print("Col_Means = :", Arr_Mean_Cols)

#------------------------------------------------
# methods for Boolean Arrays 
#------------------------------------------------
# Create an array of 10 Random nos 
Arr10 = random.randn(10)
# Find out how many are positive numbers 
Poscnt = (Arr10 > 0).sum()
print("nos of pos numbers in Arr10 is : ",Poscnt)
print("Arr10 is : ",Arr10)

#--------------------------------------------
#   Sorting 
#--------------------------------------------
Arr10_Sorted = sorted(Arr10) 
print("Unsorted Array is ",Arr10)
print("Sorted Array is ",Arr10_Sorted)
#-------------------------------------------------
#  Unique  and other Array set operations 
#-------------------------------------------------
# Create a Names Array 
Names_Arr = array(["Jim","Bob","Roy","Rajesh","Roy","Kumar","Jeet","Roy","Joy"])
# Get Unique Names 
Names_Arr_Unq = unique(Names_Arr)
print("Unique Names are ",Names_Arr_Unq)
#-----------------------------------------------------
# Linear Algebra Modules in Python - Examples 
#-----------------------------------------------------
# Matrix Multiplication Dot Product 
A_Mat = array([[1,2],[3,4]])
B_Mat = array([[1,2],[3,4]])
Dot_Prod_A_B = dot(A_Mat,B_Mat)
print("Dot Product A and B ",Dot_Prod_A_B)

# Trace of a matrix ( Sum of diag elements )
Trace_A = trace(A_Mat)
print("Trace of A Mat is ", Trace_A)

#-----------------------------------------------------
#  Data Processing with Arrays 
#-----------------------------------------------------
# Example of the meshgrid command 
# Evaluate the Function of Sqrt(X^2 + Y^2) over  a square grid 
# Create 1000 Equally spaced points 
import numpy as np 
pdata = np.arange(-5,5, 0.01)
Xdata,Ydata = meshgrid(pdata,pdata)
# lets see what Xdata and Ydata looks like now
Xdata
Ydata 

# Create Z values for each of the grid points 
z = np.sqrt(Xdata ** 2 + Ydata ** 2)

# Import Plot library 
import  matplotlib.pyplot  as plt

plt.imshow(z,cmap= plt.cm.gray); plt.colorbar()
plt.title("Image plot of $\sqrt{x^2 + y^2}$ for a grid of values")


#-----------------------------------------------------
# Random number generation 
#-----------------------------------------------------
# Generate a 4 by 4  Array of random numbers following 
# Normal distribution 
#------------------------------------------------------
Arr4by4 = random.normal(size=(4,4))

#-------------------------------------------------------
# Case Study on Random Walk 
#------------------------------------------------------
# Notes : we are generating a 100 step random walk and will plot it 
#----------------------------------------------------------------
import random 
pos = 0 
walk = [pos]
steps = 100
for i in arange(100):
    step = 1 if random.randint(0,1) else -1 
    pos = pos + step 
    walk.append(pos)
    
plt.plot(walk)   



 











# Sum 