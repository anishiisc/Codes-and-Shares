
#---------------------------------
# Python Module 7 :  FILE I/O 
# -------------------------------
import pandas as pd 
from numpy import *
from scipy import *
#----------------------------------------------------------------------
# Reading a csv file into a DataFrame 
#-----------------------------------------------------------------------------
df= pd.read_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/ex1.csv',encoding = 'ISO-8859-1')
df

# Read a file without headers 
df2 = pd.read_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/ex2.csv',encoding = 'ISO-8859-1', header=None)
df2


# Assign headers at time of file read
hdr = ['a', 'b', 'c', 'd', 'message']
df3 = pd.read_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/ex2.csv',encoding = 'ISO-8859-1', names=hdr)
df3


# Assign headers and index at time of read
hdr = ['a', 'b', 'c', 'd', 'message']
df4 = pd.read_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/ex2.csv',encoding = 'ISO-8859-1', names=hdr,index_col='message')
df4

#  Read a text file  with no fixed delimiter : use reg exp 
df5 = pd.read_table('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/ex3.txt', sep='\s+')
df5


#-----------------------------------------------------------------------------
#  In built file operations 
#-----------------------------------------------------------------------------
# Skipping certain rows during read 
#-----------------------------------------------------------------------------
df6 = pd.read_table('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/ex4.csv', skiprows=[0, 2, 3],sep =',')
df6


#-----------------------------------------------------------------------------
#  NULL sentinels at time of read 
#-----------------------------------------------------------------------------
df7 = pd.read_table('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/ex5.csv', na_values=['NULL'],sep =',')
df7


#----------------------------------------------------------------------------
#  User defined NULL Sentinels customized for each column 
#---------------------------------------------------------------------------
sentinels = {'message': ['Howdy', 'NA'], 'something': ['two']}
df8 = pd.read_table('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/ex5.csv', na_values=sentinels,sep =',')
df8

#-----------------------------------------------------------------------
#  Piecmeal reading of a  file 
#-----------------------------------------------------------------------
# Method 1 : mention row count to be read : works if you need a few rows only 
df9 = pd.read_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/ex6.csv',nrows=5)
df9


# Reading a Chunk of rows 
chunkdf10 = pd.read_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/ex6.csv',chunksize=9)
type(chunkdf10)

# Note that a text parser object is returned 
# Let us display the Date Field for the chun read - iterating over the chunk 
for part in chunkdf10:
    print(part['Date'])

#-------------------------------------------------------------------------------
#   Writing data out to text format 
#-------------------------------------------------------------------------------    
df10 = pd.read_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/ex6.csv',nrows=5)
df10

# Use to_csv()  command to write out data - default is comma separated 
df10.to_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/out1.csv')

# You can specify delimiters of your choice - we use '_'  now 
df10.to_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/out2.csv',sep = '_')

# Suppress headers and index column 
df10.to_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_7/out3.csv',header=False,index=False)
#-------------  END of this Module ----------------------------------------------------



