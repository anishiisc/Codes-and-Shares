#---------------------------------
# Python Module 4 :  Data I/O  
# -------------------------------

#------------------------------
# Read from Keyboard Input 
#------------------------------

str = input("Enter your input: ")
print ("Received input is : ", str)
#----------------------------------------

# Get current Working Directory 
import os;
print (os.getcwd()) # Prints the working directory

# Set the Actual Working Directory 
os.chdir('C:/Users/roychowa/Training_Stuff/Pro_Bono_Work/Python_Tutorials/Introduction_To_Python/Module_4') # P
# Check if WD has been set correctly 
print (os.getcwd()) # Prints the working directory
#---------------------------------------------------

# Open a file for read 
Input_file = open("Test_In.dat",'r')

# Read the first four characters from the file 
string1 = Input_file.read(4)

# Display the four characters read 
print(" First four characters are : ", string1)

# Read the second line from the file 
# The first  read command reads the first line 
# The next read command would input the second line 
Input_file.readline() # Do not process this line 
string2 = Input_file.readline()
# Display the second line read 
print("The second line read is : ",string2)


# Read the third line 
string3 = Input_file.readline()

# Close Input file
Input_file.close()

# Open Output file for write
Output_file = open("Test_Out.dat",'w+')

# Write the third line read to output file
Output_file.write(string3)

# Create a new string
string4 = " This is a new string"

# Write new string to output file  in  new line 
Output_file.write('\n' + string4)

# Close Output file
Output_file.close()

# Open Output file for read
Output_file = open("Test_Out.dat",'r')
# Read all data from Output file
string5 = Output_file.readlines()
# Display data read from Output file
print("Data Read from Output file is : ",string5)
# Close Output file
Output_file.close()









