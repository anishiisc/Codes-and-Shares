# ------------------------------------------------
# Python Module 10 :  Plots 
# ------------------------------------------------
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import pandas as pd 



#---------------------------------------------------------------
# Getting started 
#---------------------------------------------------------------
plt.plot([1,2,3,4])
plt.ylabel('some numbers')
plt.show()

#--------------------------------------------------------------
# Figures and subplots 
#-------------------------------------------------------------
fig1 = plt.figure()
subfig1a = fig1.add_subplot(2, 2, 1)
subfig1b = fig1.add_subplot(2, 2, 2)
subfig1c = fig1.add_subplot(2, 2, 3)
# Now issue a plot command 
plt.plot([1.5, 3.5, -2, 1.6])
# Note: The plot was on the last subfig of the active plot 


#-----------------------------------------------------------
fig2 = plt.figure()
subfig2a = fig2.add_subplot(2, 2, 1)
subfig2b = fig2.add_subplot(2, 2, 2)
subfig2c = fig2.add_subplot(2, 2, 3)
# Different Graphs in Each Sub figure!
subfig2a.hist(np.random.randn(100), bins=20, color='k', alpha=0.3)
subfig2b.scatter(np.arange(30), np.arange(30) + 3 * np.random.randn(30))
subfig2c.plot(np.random.randn(50).cumsum(), 'k--')

#------------------------------------------------------------------
#  Color Marker and Linestyles 
#------------------------------------------------------------------
# Get list of 30 random numbers 
np.random.randn(30)
#  Get the Cumulative Sum Array for the same 
np.random.randn(30).cumsum()
# Plot with user defined color linestyle and marker style
plt.plot(np.random.randn(30).cumsum(), color='k', linestyle='dashed', marker='o')


#--------------------------------------------------------------------
#  Setting title  axis labels   ticks and  ticklabels 
#--------------------------------------------------------------------
# Step 1 - Create a Simple Random Walk  plot 
fig3 = plt.figure();
subfig3a  = fig3.add_subplot(1, 1, 1)
subfig3a.plot(np.random.randn(1000).cumsum())
# Step 2 - Now add tick points 
ticks = subfig3a.set_xticks([0, 250, 500, 750, 1000])
# Step 3 - Now provide user defined tick labels 
labels = subfig3a.set_xticklabels(['one', 'two', 'three', 'four', 'five'],  \
         rotation=30, fontsize='small')
# Step 4 - Now provide  title and axis labels 
subfig3a.set_title('My first matplotlib plot')
subfig3a.set_xlabel('Stages')
subfig3a.set_ylabel('Random Walk')

#----------------------------------------------------------------------
#  Adding Legends 
#----------------------------------------------------------------------
fig3 = plt.figure();
subfig3a  = fig3.add_subplot(1, 1, 1)
subfig3a.plot(np.random.randn(1000).cumsum(),'k',label='one')
subfig3a.plot(np.random.randn(1000).cumsum(),'k--',label='two')
subfig3a.plot(np.random.randn(1000).cumsum(),'k.',label='three')
subfig3a.legend(loc='best')
#--------------------------------------------------------------------------
#  Saving plots to file 
#-------------------------------------------------------------------------
# Saving the active figure 
plt.savefig('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_10/fig3.pdf')

#---------------------------------------------------------------------------
#                             Plot With Pandas 
#---------------------------------------------------------------------------

#--------------------------
#  Plotting Series Object 
#--------------------------
Ser1 = pd.Series(np.random.randn(10).cumsum(), index=np.arange(0, 100, 10))
Ser1.plot()

#-------------------------
# Plotting DataFrame object 
#-------------------------
# Create the DataFrame 
df = pd.DataFrame(np.random.randn(10, 4).cumsum(0),
     columns=['A', 'B', 'C', 'D'],
     index=np.arange(0, 100, 10))

# Plot the Data Frame 
df.plot()
# Notes:  Each column is plotted on a separate line in the same sub plot

#----
# Let us now try plotting in different subplots 
#----
df1 = pd.DataFrame(np.random.randn(10, 4).cumsum(0),
     columns=['A', 'B', 'C', 'D'],
     index=np.arange(0, 100, 10))
df1.plot(subplots='TRUE')


#----------------------------------------------------------------------------
#     Bar plots 
#----------------------------------------------------------------------------
# Bar Plot with Series Data 
#--------------
# Define a 2 by 1 Figure and Sub Figure 
fig4, subfig= plt.subplots(2, 1)
# Define a data series 
data1 = pd.Series(np.random.rand(16), index=list('abcdefghijklmnop'))
data1.plot(kind='bar', ax=subfig[0], color='k', alpha=0.7)
data1.plot(kind='barh', ax=subfig[1], color='k', alpha=0.7)

#-------------
# Barplot with DataFrames 
#-------------
df2 = pd.DataFrame(np.random.rand(6, 4),
     index=['one', 'two', 'three', 'four', 'five', 'six'],
     columns=pd.Index(['A', 'B', 'C', 'D'], name='Genus'))
df2.plot(kind='bar')

#----------
#  Stacked Bars 
#----------
df3 = pd.DataFrame(np.random.rand(6, 4),
     index=['one', 'two', 'three', 'four', 'five', 'six'],
     columns=pd.Index(['A', 'B', 'C', 'D'], name='Genus'))
df3.plot(kind='bar',stacked='TRUE')


#-----------------------------
# Histogram 
#-----------------------------
# Read in the tips database 
tips = pd.read_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_10/tips.csv')
# view the structure of the tips data 
tips.head()
# Create a New column - Tip % of Total Bill 
tips['tip_pct'] = tips['tip'] / tips['total_bill']

# Create 50 bins 
tips['tip_pct'].hist(bins=50)


#------------------------------------
# scatter plot
#------------------------------------
np.random.seed(19680801)
# Note  rand would generate rand numbers between 0 and 1 

N = 50
x = np.random.rand(N)
y = np.random.rand(N)
colors = np.random.rand(N)
area = np.pi * (15 * np.random.rand(N))**2  # 0 to 15 point radii
# alpha = blending value 0 to 1 
plt.scatter(x, y, s=area, c=colors, alpha=0.5)
plt.show()


#------------------------------------------------------------------------------
#   ADVANCED PLOTTING CASE STUDY : HAITI DATA
#------------------------------------------------------------------------------
haiti = pd.read_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_10/haiti.csv')
haiti.head()

# ------------  Notes 
# Each row represents a report sent from someone’s mobile phone indicating
# an emergency or some other problem. Each has an associated timestamp and a location
# as latitude and longitude:
#---------------------------------

# Check the Category column   1st 5 rows 
haiti['CATEGORY'][:5]

#---------------------------------------------------------
# Notes:  The CATEGORY field is a comma separated set for CATEGORY codes
# We see from above certain fields are missing 
#------------------------------------------------------------

# Check the location data 
#------------------------
haiti.describe()

#----------------------------------------------
# Notes 
# We find some Lat and long figures are way off and thus incorrect
#-----------------------------------------------------------------

# Clean Bad Locations 
haiti = haiti[(haiti.LATITUDE>18)&(haiti.LATITUDE<20)&(haiti.LONGITUDE > -75)&(haiti.LONGITUDE <-70)] 

# Clean null in Category 
haiti =  haiti[haiti.CATEGORY.notnull()]

# Let us chck the Haiti data once more 
haiti.head()

#-----------------------------------------------------------------------
#-----------  Extracting information from the CATEGORY Column ---------
#-----------------------------------------------------------------------
#  Notes:  1)   The CATEGORY Column may have Comma separated entries
#           2)   Each Entry has a code and description 
#             3)   Each Category code is in English and French 
#----------------------------------------------------------------------
# Lets Check with One Category Entry 
Row6_cat = haiti['CATEGORY'][6]
#  Display 
print(Row6_cat)
#  Let us now split the current string from the ',' 
Row6_Cat_Split = Row6_cat.split(',')
# Display 
Row6_Cat_Split 
#  Let us check the type  
type(Row6_Cat_Split)
#------------------------------------------------------------------------
# Notes  1)  We find it to be a list 
#         2)  The last item is a white space 
#          3)  Code is followed by a period 
#           4)  French Name is followed by English Name separated by a |
#-----------------------------------------------------------------------
# Let us loop through the list items  and strip the blanks of each item 
for cat in Row6_Cat_Split:
    Cat_Stripped = cat.strip()
    print(Cat_Stripped)
#----------------------------------------------------------------------
    
#----------------------------------------------------------------------
#  Define Strip Function to Strip Blank spaces and choose data only entries    
#
# Input -  A Category Entry
# Output   Stripped List - with data only items 
#-----------------------------------------------------------------------
def cat_strip_list(cat):
    stripped_cat = (x.strip() for x in cat.split(','))
    return [x for x in stripped_cat if x ]      
#------------------------------------------------------------------------
# Now pass a Category Item to the function and check its output 
R6_Strip = cat_strip_list(Row6_cat)
# Check Output Type 
type(R6_Strip)
# Check Output Length 
len(R6_Strip)
# Notes :  We find the output is a list with the blank space stripped out 
#------------------------------------------------------------------------
# Now Let us convert the Category List after blank space stripping to a set 
#--------------------------------------------------------------------------
# Note: All Category Data is in haiti.CATEGORY 
# Step1:   Let us take One element (Index Value = 6)
Row6_Cat = haiti['CATEGORY'][6]
# Display this Row for CATEGORY Column 
print(Row6_Cat)
# Step2: Strip This Row of blanks 
Row6_Cat_Stripped = cat_strip_list(Row6_Cat)
# Display after stripping blanks 
print(Row6_Cat_Stripped) 
#--------------------------------------------------------------
#   We need to combine All the Category Information 
#   We resort to the 'SET' Object type in Python 
#   We will use the UNION Operation of the SET Object 
#--------------------------------------------------------------
#   Quick Notes on SETS  and  Lists 
#--------------------------------------------------------------
#   1) sets — Unordered collections of unique elements
#   2) lists - ordered collections of elements
#   3) sets allow operations such as intersection, union, difference, 
#   4) sets doesn't allow indexing and are implemented on hash tables.
#   5) lists are really variable-length arrays
#   6) In lists the elements are accessed by indices
#---------------------------------------------------------------
# Convert to Set 
Cat_Set = set(Row6_Cat_Stripped)

# Add Row 7 Stripped to same set 
Row7_Cat = haiti['CATEGORY'][7] 
Row7_Cat_Stripped = cat_strip_list(Row7_Cat)
new_set = set(Row7_Cat_Stripped)
All_set = new_set.union(Cat_Set)
#--------------------------------------
# Add Row 10 stripped to above 
Row10_Cat = haiti['CATEGORY'][10] 
Row10_Cat_Stripped = cat_strip_list(Row10_Cat)
new_set2 = set(Row10_Cat_Stripped)
All_Set = All_set.union(new_set2)
#------------------------------------
# Now Display after union 
All_Set
#----------------------------------------------------------
# Now Let us try to convert ALL the Category entries to sets 
#-----------------------------------------------------------
# STEP 1 Extract  CATEGORY COLUMN 
cat_Series = haiti['CATEGORY']

# Convert to Set after using Strip/ Split Function 
# Use Inline function call 
cat_sets = (set(cat_strip_list(x)) for x in cat_Series)
# Check Type 
type(cat_sets)
# Note cat_sets is NOT a LIST its a GENERATOR OBJECT :- 
# - REFER HANDOUT on GENERATORS AND ITERATORS 
#------------------------------------------------------
# Let  us Check data type of each element of the generator 
type(next(cat_sets))
# Let us Display one of them 
next(cat_sets)
#  note Each element is a set and Thus We can do Union on them 
#-------------------------------------------------------------
#  A Simple Example of a Generator Object and extracting its items 
#-------------------------------------------------------------
g = (x for x in range(3))
type(next(g))
next(g)
next(g)
next(g)
#------------------------------------------------------------

#------------------------------------------------------------
# Now Let us Write a Function to GET ALL CATEGORIES 
# Function : Cat_2_Set
# Input -  Category Column from raw data 
# Output - Sorted Set of individual categories 
#-------------------------------------------------------
def get_all_categories(cat_series):
 cat_sets = (set(cat_strip_list(x)) for x in cat_series)
 return sorted(set.union(*cat_sets))
#----------------------------------------------
# Call this function to get a List of ALL Categories 
ALL_CATS = get_all_categories(cat_Series)
#-----------------------------------------------------
# Notes:   Now we have a LIST of ALL UNIQUE CATEGORIES 
#-----------------------------------------------------
# Let us extract 5th item of this list 
Cat_5 = ALL_CATS[5]
print(Cat_5)
#--------------------------------------
# Let us now try to extract the Names and the codes 
code, names =  Cat_5.split('.')
# Let us check the code number 
print(code)
# Let us Check the names 
print(names)
# Notes:  Names May have both French and English Version 
#         If a | symbol exists then its the separator
#--------------------------------------------------------
#  Get the English Name 
if '|' in names:
    # Note the Split would return Two positions : We want the second pos 
    English_Name = names.split('|')[1]
    print("English Name is : ", English_Name)

#---------------------------------------
# Let us Now Write a Function to Strip our Code and English Name 
# Input - CATEGORY 
# Output - Code and English  Name 
#---------------------------------------------------
def get_code_Eng_name(cat):
    code,names = cat.split('.')
    if '|' in names:
        names = names.split('|')[1]
    return code,names.strip()
#----------------------------------------------------
# Check this function : provide 5th Cat entry as Input 
CatCode,EngName = get_code_Eng_name(Cat_5)
print(CatCode)
print(EngName)
#---------------------------------------------------- 
#----------------------------------------------------
#  Putting it Al Together !!!
#----------------------------------------------------   
# STEP1:  Get All the Categories 
#---------------------------------
ALL_CATS = get_all_categories(haiti['CATEGORY'])
#----------------------------------------------------
# STEP2 :  Get Code and English Name 
#----------------------------------------------------
# Note :  (get_code_Eng_name(x) for x in ALL_CATS)   
#          Above is agenerator expression 
#          We are converting the output to a dict 
#----------------------------------------------------
Eng_mapping = dict(get_code_Eng_name(x) for x in ALL_CATS)
# Check the Keys and Values of this dict 
Eng_mapping.keys()
Eng_mapping.values()
#-----------------------------------------------------------------------
#  Quick Check : Let us see how ith element of ALL_CATS look like
ALL_CATS[4]  
#-----------------------------------------------------------------------
# NOTES: AT THIS POINT OF TIME WE HAVE 
#  1) A Dictionary Which has Category Code mapped to its English  Name 
#-----------------------------------------------------------------------
# Let us now Try to get a Unique List of Category Codes 
#---------------------------------------------------
# Definining Function gect_codes
# Input : ALL  Categories 
# Output ALL Category Codes 
#---------------------------------------------------
def get_codes(allcats):
    return [x.split('.')[0] for x in allcats if x]
#----------
all_codes = get_codes(ALL_CATS)
all_codes
#------------------------------------------------
# Now Create an Index Object  with all the unique codes
code_index = pd.Index(np.unique(all_codes))
#---------  Why Did we do this ? We shall see shortly!
#------------------------------------------------------
#     Next Steps!
#     Let us Now Create a Dummy Data Frame 
#      Notes:  This will have As many columns as we have unique CATEGORIES 
#              This will have As many Rows as is in the original Data Set  
#--------------------------------------------------------
Row_Cnt = len(haiti)
Col_Cnt = len(code_index)
Zero_data = np.zeros(shape=(Row_Cnt,Col_Cnt))
Dummy_DF = pd.DataFrame(Zero_data, index= haiti.index,columns=code_index)
# Let us now Check how it  looks 
Dummy_DF.head()
#----------------------------------------------------------------
#  Now What do we do with this Matrix of Zeros?
# - Yes You Guessed it Right!
#    We Set to 1 the Appropriate CATEGORY Column of Each Row !
#-----------------------------------------------------------------------------------------
# How Do We Do This ?
# Pseudo Code Steps:  We Have to  Iterate through All the Rows : 
#                      Get the Category Entries and Index Pos of Current Row  
#                      Get the Codes Associated with the Category Entries 
#                      For the Current Row ( Index ) Pos Set all Column (Code Index ) to 1 
#-----------------------------------------------------------------------------------------
# Note We Are Using Parallel Iterations -   using Zip -  Both the lists are of the same length 
#--------------------------------------------------------------------------------------------
for row, cat in  zip(haiti.index,haiti['CATEGORY']):
             #print(cat)
             Cats = (cat_strip_list(cat))
             #print(Cats)
             codes = get_codes(Cats)
             #print(codes) 
             # Note this is not a Row  Col Position BUT a Row Col Index Match 
             Dummy_DF.ix[row,codes] =1 
#-----------------------------------------------------------------------------------------------
# Notes:   At this stage We have a Dummy DF with Same nos of rows as Original haiti data 
#          Dummy DF has same Row Indices as original  haiti  data 
#          Dummy DF has  Additional COlumns for Each Unique CATEGORY 
# ----------------------------------------------------------------------------------------------
#         MERGE Dummy DF with  haiti data : Add Prefix category_ to the Cols of Dummy_DF
#-----------------------------------------------------------------------------------------------                   
haiti = haiti.join(Dummy_DF.add_prefix('category_'))     
haiti.head()

#--------------------------------------------------------------------------------
# How Does the haiti data now look like?  Let us write out to a csv and check !
#----------------------------------------------------------------------------------
haiti.to_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_10/haiti_out1.csv')
#-----------------------------------------------------------------------------------------
#   NOW the REAL PLOTTING FUN BEGINS 
#   At this Point You must have installed 'basemap'   for the plot to work 
#   use :
#        pip install https://github.com/matplotlib/basemap/archive/v1.0.7rel.tar.gz 
#  NOTE : The install will take a while !!!;   
#---------------------------------------------------------------------------------------
from mpl_toolkits.basemap import Basemap







