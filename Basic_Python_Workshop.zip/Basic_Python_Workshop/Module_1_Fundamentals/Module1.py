# MODULE 1 Python -  Basics 
# Hello World 
print("Hello World")

#Indentation : Correct Way 
if True:
    print ("True")
else:
  print ("False")
  
  
# Indentation : Improper 
if True:
    print ("Answer")
    print ("True")
else:
    print ("Answer")
print ("False")

# Now indent above line properly and re run above code snippet 


# Multiline
item_one = 1
item_two = 2
item_three = 3
total = item_one + \
        item_two + \
        item_three
        
print("Total=",total)        

# Array elements declaration 
Day_of_Week = ["Mon","Tue","Wed",
              "Thu","Fri","Sat","Sun"]
              
print("1st Week day is ",Day_of_Week[0])

# Multi line statements as suite 
if 5>6 : 
   print("5 is GT 6 ")   
   print(" 5 is greater  than 6" )
elif 3 > 2 : 
   print(" 3 is GT 2 ")  
   print("3 is greater than 2 ")
else : 
   print(" nothing matched ")
   
   
   
 # Multiple commands in one line 
x=4; y=5; z = x + y ; print("z = x +y = ",z)

#Multiple Assignment 
a = b = c = 1
print(a,b,c)

#Multiple values to multiple variables
a,b,c = 1,2,"john"
print(a,b,c)



#Numeric Data Types
a = 5; # integer 
b = 5.5 # float 
c = 3.5+ 1.2j # complex 
d = 123456789 # long integer 
print("Integer a = ",a)
print("float   b = ",b)
print("complex  c = ",c)
print("Long Integer d = ",d)



# Strings
str = 'Hello World!'

print (str)          # Prints complete string
print (str[0])       # Prints first character of the string
print (str[2:7])     # Prints characters starting from 3rd to 5th
print (str[2:])      # Prints string starting from 3rd character
print (str * 3)      # Prints string two times
print (str + "TEST") # Prints concatenated string


# lists
list1 = [ 'abcd', 1234, 23.2, 'pqr', 99 ]
sublist1 = [1234, 'abcd']

print (list1)          # Prints complete list
print (list1[0])       # Prints first element of the list
print (list1[1:3])    # Prints elements starting from 2nd till 3rd 
print (list1[2:])      # Prints elements starting from 3rd element
print (sublist1 * 3)  # Prints list two times
print (list1 + sublist1) # Prints concatenated lists

list1[1] = 25        # change second element of a list 
print(list1)         # Prints entire list  


# tuples - Read only lists 
tuple1 = ( 'abcd', 1234, 23.2, 'pqr', 99 )
subtuple1 = (1234, 'abcd')

print (tuple1)           # Prints complete list
print (tuple1[0])        # Prints first element of the list
print (tuple1[1:3])      # Prints elements starting from 2nd till 3rd 
print (tuple1[2:])       # Prints elements starting from 3rd element
print (subtuple1 * 2)   # Prints list two times
print (tuple1 + subtuple1) # Prints concatenated lists

tuple1[1] = 25 
# Dictionary 
dict1 = {}
dict1['one']       = "Alpha"
dict1[2]           = "Beta"
dict1[2]     = "Gamma"

dict2 = {'Name': 'Joe','roll':1234, 'Dept': 'Sales'}

print (dict1['two'])     # Prints value for 'one' key
print (dict1[2])         # Prints value for 2 key
print (dict1)            # Prints complete dictionary
print (dict2.keys())     # Prints all the keys
print (dict2.values())   # Prints all the values


# Basic  Operators 
#----------------------------------------
# Arithmetic Operators 
a = 11
b = 5
c = 0
x = 2
y = 5
#------------------------------------
c = a + b # sum 
print("a+b = ",c)

c = a - b  #subtraction 
print("a-b = ",c) 

c = a * b # Multiplication 
print("a*b = ",c) 

c = a / b # Division 
print("a/b = ",c)

c = a // b # Division 
print("a//b = ",c)

c = a % b # Modulo Division 
print("a%b = ",c)

c = x**y # exponent
print("x**y = ",c) 

# Comparison Operators
#---------------------------------------------
a = 21;b = 10;c = 0

if ( a == b ):  # Equality check 
   print ("Line 1 - a is equal to b")
else:
   print ("Line 1 - a is not equal to b")
   
   
if ( a != b ):  # NOT operator check 
   print ("Line 2 - a is not equal to b")
else:
   print ("Line 2 - a is equal to b")
     
a = 21;b = 10;c = 0  
if ( a < b ): # Less than check 
   print ("Line 4 - a is less than b" )
else:
   print ("Line 4 - a is not less than b")
 
if ( a > b ): # Greater than check 
   print ("Line 5 - a is greater than b")
else:
   print ("Line 5 - a is not greater than b")

a = 21;b = 10;c = 0
if ( a <= b ):  # Less than equal 
   print ("Line 6 - a is either less than or equal to  b")
else:
  print ("Line 6 - a is neither less than nor equal to  b")

if ( b >= a ):  # Greater than equal 
   print ("Line 7 - b is either greater than  or equal to b")
else:
   print ("Line 7 - b is neither greater than  nor equal to b")
   
   
#--------------------
# Assignment Operators 
   
a = 15
b = 10
c = 0

c = a + b
print ("Line 1 - Value of c is ", c)

c += a
print ("Line 2 - Value of c is ", c )

c *= a
print ("Line 3 - Value of c is ", c )

c /= a 
print ("Line 4 - Value of c is ", c )

c  = 2
print ("Line 5 - Value of c is ", c)

c **= a
print ("Line 6 - Value of c is ", c)

c //= a
print ("Line 7 - Value of c is ", c)  

# Logical Opeartors

# AND 
a = 1; b = -2.5
if (a and b): 
   print ("Both 'a' and 'b' !=0") 
else:
   print ("Either 'a' or 'b' or both =0")
   
# OR
a = 0; b = 0
if (a or b): 
   print ("at least one of 'a' or 'b' !=0") 
else:
   print (" both 'a' and 'b' =0")
   
# NOT
a = 4; b = 6
if not (a>b): 
   print ("a is <= b") 
else:
   print ("a is > b ")
   
   
# Membership operator 
a = 10
b = 2
list = [1, 2, 3, 4, 5 ];

if ( a in list ):
   print ("Line 1 - a is available in the given list")
else:
   print ("Line 1 - a is not available in the given list")

if ( b not in list ):
   print ("Line 2 - b is not available in the given list")
else:
   print ("Line 2 - b is available in the given list")
   
   
   