#---------------------------------
# Python Module 6 :  Panda's 
# -------------------------------

#---------------------------------------------
# 1D Data Structure - the series 
#---------------------------------------------
from pandas import *
from numpy import *
from scipy import *
Series1  = Series([1, 2, 3, 4])
print("Series 1 is : ",Series1)
# Extracting the Index and Values separately from a Series 
Series1_Val = Series1.values
Series1_Idx = Series1.index
print("Series values ",Series1_Val)
print("Series Indices ",Series1_Idx)

#-------------------------------------------
# Specifying a Series with Indics pre defined
#-----
Series2 = Series([1,2,3,4], index=['a','b','c','d'])
print("Series2 = ",Series2)

#-------------------------------------------
# Converting Dictionary to Series 
#------------------------------------------
sdata = {'Ohio': 35000, 'Texas': 71000, 'Oregon': 16000, 'Utah': 5000}
Series_State = Series(sdata)
# Now Check if Indices have the Keys 
print("Indices of Series are Keys of Dict: ",Series_State.index)
# Now check if the key value comes in values 
print("Value of the Series is the Value of the Dict: ",Series_State.values)
# Now consider passing Only key Values  with A Invalid Key 
States1 = ['Ohio','Texas','Oregon','California']
Series_State2 = Series(sdata,index=States1)
# Check Values now with this Key 
print("Values based on new key set ",Series_State2.values)
# Observe the NA in the position of the invalid key 
# ----------------------------------------------------------------
# Detecting missing data in series
#-----------------------------------------------------------------
NullCheck = isnull(Series_State2)
print("NullCheck is :  " ,NullCheck)

# ------------------------------------------------------------
# Naming the index and the Value Attributes in a Series 
#------------------------------------------------------------
Series_State.name = 'population'
Series_State.index.name = 'State'
print("State Series ", Series_State)
#-------------------------------------------------------------
#  DATA FRAMES
#-------------------------------------------------------------


# Create a Data Frame from a Equal length list or numpy arrays 
data = {'state': ['Ohio', 'Ohio', 'Ohio', 'Nevada', 'Nevada'],
'year': [2000, 2001, 2002, 2001, 2002],
'pop': [1.5, 1.7, 3.6, 2.4, 2.9]}

# Check data type to confirm its a dictionary 
type(data)

# Display the keys of this dictionary
data.keys()

# Convert to Dataframe 
df = DataFrame(data)

# Display the DataFrame 
df # Note column names are in alphabetical order 

# Customize column sequence 
df_new = DataFrame(data, columns=['year', 'state', 'pop'])

# Retrieving col information 
State_Data = df_new.state

# Display Retrieved Col 
State_Data 

# Check the indices for this dataframe
df_new.index

# Print data for index position 2 
df_new.ix[2]

# Re set data values - Year col all set to a scalar 
df_new['year'] = 2001

# re check data in this data frame : All year values changed to 2001 
df_new

# Create a New column 
df_2 = DataFrame(data, columns=['year', 'state', 'pop', 'debt'])

# display new data frame 
df_2

# Fill Data in specified index positions in New Col 
val = Series([-1.2, -1.5, -1.7], index=[0, 1, 2])
df_2['debt'] = val 

# Display Dataframe again 
df_2 
# Create a Computed Column 
# Just assign a column which does not exist 
# eg create a col which is true f state is Eastenr State of Ohio 
df_2["Eastern"] = df_2.state == 'Ohio'

# Display  again 
df_2
# Delete a column 
del df_2["Eastern"]
# Display again 
df_2

#-------------------------------------
# Creating a Data Frame from a nested dict of dicts 
#-------------------------------------------------------------
pop = {'Nevada': {2001: 2.4, 2002: 2.9},
        'Ohio': {2000: 1.5, 2001: 1.7, 2002: 3.6}}
df_3 = DataFrame(pop) 
# Display 
df_3 
# We can transpose as well 
df_3_T = df_3.T 
# Display Transposed 
df_3.T 

#-------------------------------------------
# RE Indexing 
#--------------------------------------------
 # Create A Object with Index 
OB_One = Series([4.5, 7.2, -5.3, 3.6], index=['d', 'b', 'a', 'c'])
# Display Object 
OB_One
# re Index Object 
OB_Two = OB_One.reindex(['a','b','c','d','e'])

# Display 
OB_Two
#------------------------------------------
# Dropping entries from axis 
#-------------------------------------------
# eg with 1D data i.e. series 
#---------------------------------
# Create Series 
Ser1  = Series(np.arange(5.), index=['a', 'b', 'c', 'd', 'e'])
# Drop data for index value = c 
New_Ser = Ser1.drop('c')
# Display after drop 
New_Ser

#----------------------------------
#  With 2 D data i.e. dataframes
#----------------------------------
# Create data Frame Note: Matrix fills By Row as default 
DF = DataFrame(np.arange(16).reshape((4, 4)),
  index=['Ohio', 'Colorado', 'Utah', 'New York'],
  columns=['one', 'two', 'three', 'four'])
  
 # Display DF 
DF  
# drop rows 
DF_1 = DF.drop(['Colorado', 'Ohio'])
# Display DF
DF_1
# Drop columns : note columns are treated as axis 1 
DF_2 = DF.drop('two',axis=1)
# Display 
DF_2

#------------------------------------------------------------
#  Subselect data using indexing  - 1D Array 
#------------------------------------------------------------
# Create a numeric array of size 6 
Ser1 =  Series(np.arange(5.),index=['a', 'b', 'c', 'd','e'])
# Display the Series 
Ser1
# Index by Index Name directly
Ser1_Idx_b = Ser1['b']
# Display extract
Ser1_Idx_b
# Use a Index range to Redefine Series elements 
Ser1['b':'d'] = 55
# Display after Re indexing 
Ser1
#-------------------------------------------------------------
#  Subselect data using indexing - 2D Array 
#-------------------------------------------------------------
# Create a DF : We use the DF created already above 
# Check DF 
DF
# Slice Two columns from DF 
# Note the Double Subscripting  to refer to columns 
DF_subset = DF[['two','three']]
# Display 
DF_subset 
#-------------------------------
# Replace all data  values less than 5 with zeros 
#--
DF[DF < 5] = 0
# Check replacement 
DF
#-------------------------------------------------------
# Use Special indexing ix  to subselect rows then  cols 
#-------------------------------------------------------
DF_One_row_2Cols = DF.ix['Colorado', ['two', 'three']]
# Display 
DF_One_row_2Cols 

# Row pos 2 col pos 3
DF_Row2_Col3 = DF.ix[1,2]
# Display 
DF_Row2_Col3
#---------------------------------------------------------
#  Union of Series 
#---------------------------------------------------------
# Def Series 1
Ser_1 =  Series([7.3, -2.5, 3.4, 1.5], index=['a', 'c', 'd', 'e'])
# Def Series 2
Ser_2 = Series([-2.1, 3.6, -1.5, 4, 3.1], index=['a', 'c', 'e', 'f', 'g'])

# Union 
Ser_New = Ser_1 + Ser_2 
# Display 
Ser_New 
#----------------------------------------------------------
#  Union of Data Frame 
#----------------------------------------------------------
# Def data Frame 1 
#----------------------------------------------------------
df1 = DataFrame(np.arange(9.).reshape((3, 3)), columns=list('bcd'),
          index=['Ohio', 'Texas', 'Colorado'])
# Display 
df1
#----------------------------------------------------------
# Def data Frame 2 
#----------------------------------------------------------
df2 = DataFrame(np.arange(12.).reshape((4, 3)), columns=list('bde'),
 index=['Utah', 'Ohio', 'Texas', 'Oregon'])

# Display 
df2
# Union 

df_new = df1 + df2
# Display 
df_new
# Observe all non match col and index pos are filled with NAn
#-----------------------------------------------------
#--    Add with fill value for Nans
df1 = DataFrame(np.arange(12.).reshape((3, 4)), columns=list('abcd'))
df2 = DataFrame(np.arange(20.).reshape((4, 5)), columns=list('abcde'))

#-----------
#  Display 
df1
df2
#---------------------------
# Use fill value of 0 to fill up cases of no overlap
df_new2 = df1.add(df2, fill_value=0)
# Display 
df_new2

#---------------------------------------------------------------
#  OPerations between DF and Series 
#------------------------------------------------------------
# Define a 2D DF 
df1 = np.arange(12.).reshape((3, 4))
# Display 
#----------------------
# Extract 1st Row 
df_1st_row = df1[0]
# Display 
df_1st_row
# Subtract 1st Row from the 2D Array 
#------- Note that the operations will apply to all rows 
# Also called broadcast  method
# Index match of cols : broadcast down the rows 
df_subtract = df1 - df_1st_row
# Display 
df_subtract

#--------------------------------------------------------------------
# Applying Functions to Data Frame cols or Rows 
#-----------------------------------------------------------------
df1 = DataFrame(np.arange(12.).reshape((3, 4)), columns=list('abcd'))
# Display 
df1
# ----------------------------------------------------------------------
#  default - summary applied over cols 
#-------------------
MaxCol = np.max(df1)
MaxCol
#  summary applied over rows 
MaxRow = np.max(df1,axis=1)
MaxRow

#-------------- Using apply function for user Defined Functions 
#-
# Define  inline function 
f = lambda x: x.max() - x.min()
Func_Res = df1.apply(f)
Func_Res
df1


#-------------------------------------
# Sorting and Indexing 
#--------------------------------------
# 1)  sorting lexicographically by index 
#----------------------------------------------
# define series  
df1 = Series(range(4), index=['d', 'a', 'b', 'c'])
#  Display 
df1 
# Sort on index 
df1_sorted = df1.sort_index()
df1_sorted
#-------------------------------------------------------------------
# Sorting for 2D  Frame 
# Create a 2D DF
DF2 = DataFrame(np.arange(8).reshape((2, 4)), index=['three', 'one'],
 columns=['d', 'a', 'b', 'c'])
#-------------------------------------------------------------------
# Display 
#------------------------------------------------------------------
DF2
# Sort Index
DF2_Srted = DF2.sort_index()
# Display Sorted ( row index by default chosen )
DF2_Srted 
# sort by col index 
DF2_col_srt = DF2.sort_index(axis=1)
# Display 
DF2_col_srt

#--------------------------------------------------------------------
# Descriptive Statistics 
#--------------------------------------------------------------------
df = DataFrame([[1.4, np.nan], [7.1, -4.5],
      [np.nan, np.nan], [0.75, -1.3]],
      index=['a', 'b', 'c', 'd'],
      columns=['one', 'two'])

# Display 
df
# Compute Sum : default col is summed 
DFSUM = df.sum()
DFSUM
# row sum 
DF_Row_SUM = df.sum(axis=1)
DF_Row_SUM

#--------------------------- Summary Statistics of each col 
# Applied to numeric data it produces summary statistics 
df.describe()

# Create non Numeric Series 
Ser_1 = Series(['a', 'a', 'b', 'c'] * 4)
# Applied to Non Numeric data : different type of summary is provided 
Ser_1.describe()

#------------------------------------------------------------
# Correlation - Studies ------------------------------------- 
#------------------------------------------------------------
# Create a Series 
Ser1 = Series([10,12,27,35,42])
# Create a Perfectly correlated Series to Ser1
Ser2 = Ser1 + 10 

# Create a Not so perfectly correlated series this time 
len1 = Ser1.size 
Ser3 = Series()
for i in range(len1):
   Ser3 = Ser3.set_value(i,random.randint(0,5))
   
   

# Initialize New Series 
Ser4 = Series()   
# Series 4 is NOT perfectly correlated with Series 1 
Ser4 = Ser1 + Ser3    

# Check Correlation between Series 1 and Series 2  
Ser1.corr(Ser2)

# Check Correlation between Series 1 and Series 4
Ser1.corr(Ser4)

dfnew= DataFrame()
#now Create a Data Frame using all the Series we have 
dfnew = concat([Ser1,Ser2,Ser3,Ser4],axis=1,keys =['S1','S2','S3','S4'])
# Display combined  DataFrame
dfnew

# Correl on the DF returns a Corr Matrix 
dfnew.corr()

#------------------------------------------------------------
# Unique Values 
#-----------------------------------------------------------
# Create a Series with Duplicate values 
Ser1 = Series(['a','b','c','c','e','f','d','a','e','f','c'])
# extract Unique Values
Unique_Ser1 = Ser1.unique()
Unique_Ser1
# Get Frequency Table # default sort is Desc order of freq 
Ser1_Freq = Ser1.value_counts()
Ser1_Freq
type(Ser1_Freq)


#----------------------------------------------------------
#-----------------  Handling Missing Data -----------------
#----------------------------------------------------------
# Create String NAN 
string_data = Series(['aardvark', 'artichoke', np.nan, 'avocado'])
# test for Null  in Boolean form 
string_data.isnull()
#Store only NON Null string values 
No_Null_string = string_data[string_data.notnull()]
No_Null_string
# Another way to filter out Null values is 
string_data1 = Series(['aardvark', 'artichoke', np.nan, 'avocado'])
string_data1_Nonull = string_data1.dropna()
string_data1_Nonull

#---------------------------------------------------------------
#  Nulls with respect to dataframes 
#---------------------------------------------------------------
from numpy import nan as NA
# Create DF with NA's 
DFnew = DataFrame([[1., 6.5, 3.], [1., NA, NA],
                 [NA, NA, NA], [NA, 6.5, 3.]])
DFnew    
# Drop ALL Rows which has a missing value in ANY column 
DFnew_Clean = DFnew.dropna()
DFnew_Clean
# Drop ONLY those rows which have ALL cols as NA's 
DFnew_Semi_Clean = DFnew.dropna(how='all')
DFnew_Semi_Clean
# Create a Column of only NA's 
DFnew[3] = NA
DFnew
# Drop That Col which has ALL rows as NA's 
DFnew_Semi_Col_Clean =  DFnew.dropna(how='all',axis=1)
DFnew_Semi_Col_Clean

#-----------------------------------------------------------------
# Filling in Missing data     
#-----------------------------------------------------------------
# Fill missing values with Zeros 
DFnew_filled = DFnew.fillna(0)
DFnew_filled
# Using mean to fill up NA values in a Series 
Ser1 = Series([10,10,10,NA,NA])
Ser1_Mean_fill = Ser1.fillna(Ser1.mean())
Ser1_Mean_fill
#------------------------------------------------------------------
# Hierarchial Indexing 
#------------------------------------------------------------------
# CreateIndex
Ser1 = Series(np.random.randn(10),
       index=[['a', 'a', 'a', 'b', 'b', 'b', 'c', 'c', 'd', 'd'],
         [1, 2, 3, 1, 2, 3, 1, 2, 2, 3]])
# Access with Outer Level 
Ser1['b']
# Access with Inner level    
Ser1[:,3]    
#-------------------------------------------------------------------
#  Using a DF 's columns 
#--------------------------------------------------------------------
DF1 = DataFrame({'a': range(7), 'b': range(7, 0, -1),
                'c': ['one', 'one', 'one', 'two', 'two', 'two', 'two'],
                'd': [0, 1, 2, 0, 1, 2, 3]})
# Display 
DF1

# Set Index to one or more columns 
DF2 = DF1.set_index(['c', 'd'])
# Display 
DF2
# Reset index just does the reverse
DF3 = DF2.reset_index()
# Display 
DF3
#------------------------------------------------------------------------------------