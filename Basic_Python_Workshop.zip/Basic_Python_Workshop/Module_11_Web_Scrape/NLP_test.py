# -*- coding: utf-8 -*-
###################################################################################

############################################ Step-1- Import Libraries #####################################
import nltk
#nltk.download()
import urllib3
from pandas import * 
# Import all books in nltk package 
from nltk.book import *
# Check list of books 
#texts()

# Word Search 
# Search for  the word "Monstrous" occurs in Moby Dick 
text1.concordance("monstrous")
# Search for words used in similar context 
text1.similar("monstrous")

# Search for common contexts shared by two words
text2.common_contexts(["monstrous","very"])

# Dispersion plot - Where does a text occur 
text4.dispersion_plot(["citizens", "democracy", "freedom", "duties", "America"])


#Counting 
# How many words in the book 3  ?
len(text3)

# Get the set of vocabulary in a sorted fashion for book 3
sorted(set(text3))

# find measure of richness 
from __future__ import division
len(text3) / len(set(text3))
# Notes : We find on an avg each word is used 16 times

# How many times a particular word  has occured?
text1.count("Moby")

# What percentage of times a word occurs in a text 
100*text2.count("very")/len(text2)


# define function for lexical richness 
def lexical_diversity(text):
    return len(text)/len(set(text))

#define function for  percentage of a words occurence 
def perc_occur(text,str1):
     return 100*text.count(str1)/len(text) 
#------------------------------------------------------------ 
# Let us use these functions 
#---------------------------     
# test richness of text 3 
lexical_diversity(text3)     

# test word perc of word "very" in text 1
perc_occur(text1,"very")
#--------------------------------------------------------
#     text as list of words 
#-------------------------------------------------------
# Create a list of words 
wordlist = ['Call', 'me', 'Ishmael', '.']

#check length 
len(wordlist)


lexical_diversity(wordlist)

# Special word selection Using Sets and conditions
# Create master words set 
V = set(text1)
# Choose only long words 
long_words = [w for w in V if len(w) > 15]
sorted(long_words)

# Collocations 
# Extracting words occuring together 
text4.collocations()
#-------------------------------
# Convert a Freq Table to a Data Frame 
#--------------------------------
list1 = [1,2,1,2,2,2,2,2,2,3,4,5,5]
list1
# 
FTable = FreqDist(list1)
FTable.keys()
FreqDF = DataFrame.from_dict(FTable, orient='index').reset_index()
FreqDF

FreqDF.columns = ['column_one', 'column_two']
FreqDF

#-------------------------------------------------------------
# Playing with strings 
#---------------------------------------------------------------
name = 'Monty'
title = 'Python'
# Get first char of name 
name[0]
# Add or Multiply a string 
twotimes_name = name*2
twotimes_name
#
fullname = name + title
fullname
# Create a List  with name and title
namelist = [name,title]
namelist 

# Join words of a list to make a singel string 
nameString = ''.join(namelist)
nameString
# Now include a gap between the words
nameString1 = ' '.join(namelist)
nameString1

## Now split  a long string into list elements separated at delim 
namelist1 = nameString1.split()
namelist1

#-----------------------------------------------------------------------
#   Raw  Text Handling 
#-----------------------------------------------------------------------
# Access Raw Text from a web url 
#-----------------------------------------------------------------------
http = urllib3.PoolManager()
r = http.request('GET', 'https://www.gutenberg.org/files/56245/56245-0.txt')
# Check Status 200 means  read success
r.status
# Get Raw data 
raw = r.data
type(raw)
len(raw)
# Display teh first 80 bytes of the Raw text
raw[:80]
