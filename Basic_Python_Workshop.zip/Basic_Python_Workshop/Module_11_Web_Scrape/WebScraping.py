# -*- coding: utf-8 -*-
###################################################################################

############################################ Step-1- Import Libraries #####################################
import nltk
import urllib3
from pandas import * 
from bs4 import BeautifulSoup
#-----------------------------------------------------------------------
#   Raw  Text Handling 
#-----------------------------------------------------------------------
# Access Raw Text from a web url 
#-----------------------------------------------------------------------
http = urllib3.PoolManager()
htmldata = http.request('GET', "http://pythonscraping.com/pages/page1.html")
# Check Status 200 means  read success
htmldata.status
# Get Raw data 
raw = htmldata.data
type(raw)
len(raw)
# Display the first 80 bytes of the Raw text
raw[:80]
# Let us now convert this to a BS object
BSdata = BeautifulSoup(raw)
# Let us now print this 
print(BSdata)
# Notes: Do you notice a formatted HTML output?
#############################################################################
# Extracting Data 
#----------------------------------------------------

# Let  us extract data for the  <h1> tag 
print(BSdata.h1)
#------------------
#Now let us get the data inside the tag 
print(BSdata.h1.get_text())
#----------------------------------------------------
# Let get another book 
#---------------------------------------------------
htmldata1 = http.request('GET', "http://pythonscraping.com/pages/warandpeace.html")
raw = htmldata1.data
BSdata = BeautifulSoup(raw)
# Let us now print this 
print(BSdata)
# Notes  Observe that all the  lines spoken arfe within span class  = red 
#        Also    the character names are within span class = green 
#--------------------------------------------------------------------------
# Now let us extract out all proper nouns  using findall
#----------------------------------------------
# Print the name
namelist = BSdata.findAll("span", {"class":"green"})  
for name in namelist :
    print(name)
#------------------------------------------------
# Notes:     
# OOPS We just wanted the data inside the tags and not the whole line!    
# No Issues let us try again : this time we use our friend get_text()
 #---------------------------------------------------
namelist = BSdata.findAll("span", {"class":"green"})  
for name in namelist :
    print(name.get_text())
   
    
#  Navigating HTML Trees
#-----------------------------------------------------
htmldata1 = http.request('GET', "http://pythonscraping.com/pages/page3.html")
raw = htmldata1.data
BSdata = BeautifulSoup(raw)
# display 
print(BSdata)    
#------------------------------------------------------------------------------
# Notes: Open this url from Google Chrome : from More tools - > developer tools
#      : Study the web page:
#      Observe : We want to get All the child elements of the gift table 
#------------------------------------------------------------------------------
All_gifts = BSdata.find("table", {"id":"giftList"}).children
print(All_gifts)
# Get the children and iterate one by one 
#---------------
for gift in BSdata.find("table", {"id":"giftList"}).children:
    print(gift)
#--------------------------------------------------------------
# Example to get  Price of the object depicted by img1
#-------------------------------------------------------------    
#Note :   The tag for the image is 'img' 
#          The parent tag is td 
#          The Previous sibling of the 'td' has the price
#          We want to get the text of the price 
#--------------------------------------------------------------
print(BSdata.find("img",{"src":"../img/gifts/img1.jpg"
}).parent.previous_sibling.get_text())
#--------------------------------------------------------------
   
# Using Reg Ex     
# Using Beautiful Soup     
# Get the list of all the relative image paths 
#-----------------------------------------------------------------
import re     
images = BSdata.findAll("img", {"src":re.compile("\.\.\/img\/gifts/img.*\.jpg")})
for image in images:
 print(image["src"])    
    
#----------------------------------------------------------------------------------------------
# Starting to Crawl 
#---------------------------------------------------------------------------------------------- 
# Get all links in an arbitrary wiki page 
 #------------------------------------------------------------------------
 # First let us get the data on the page and check which tags have  urls 
 #------------------------------------------------------------------------
htmldata2 = http.request('GET', "https://en.wikipedia.org/wiki/Han_Solo")
raw = htmldata2.data   
BSdata = BeautifulSoup(raw)
# display 
print(BSdata)  
#-----------------------------------------------------------------------------------
# Note the Links are in the tag 'a'  and attribute href 
# Thus for every 'a' tag we must get the data associated with the 'href' attribute 
# -----------------------------------------------------------------------------------
for link in BSdata.findAll("a"):
  if 'href' in link.attrs:
      print(link.attrs['href'])
      
# Note How do we filter to select only those links which contain articles 
# We Observe the following filter rules 
#   1 url resides within div tag and id = bodyContent 
#   2 url's do not contain semi colons 
#   3 urls begn with WIKI 
#----------------------------------------------------------------------------------      
for link in BSdata.find("div", {"id":"bodyContent"}).findAll("a",
href=re.compile("^(/wiki/)((?!:).)*$")):
                if 'href' in link.attrs:
                    print(link.attrs['href'])      
#--------------------------------------------------------------------------------
                   
# -----------------------------------------------------------------------