# --
# Python Module 9 :  Data Manipulation 
# -------------------------------
from pandas import *
from numpy import *
from scipy import *
import re 

#---------------------------------------------------------------
# STRING MANIPULATION 
#---------------------------------------------------------------
# Split a comma seprated string 
Str1 = 'a,b,c'
Str1_Arr = Str1.split(',')
Str1_Arr 
# Create comma separated string with white spaces 
Str2 = 'aaaa, bbb,  cc'
Str2_Arr = [x.strip() for x in Str2.split(',')]
Str2_Arr
# Concatenate substrings with a delimiter 
# get the substrings 
First, Second, Third = Str2_Arr
All_in_One = First + "::" + Second + "::" + Third
All_in_One 
# Now a better way to join the substrings !
All_better = "::".join(Str2_Arr)
All_better 

# Checking for a substring within a string 
Big_str = "This is a short sentence"
Sub_str = "short"
Sub_str2 = "big"
# Check for Sub Str in Big Str 
Chk_Str = Sub_str in Big_str
Chk_Str

# Check Index pos of Sub str in Big str  with find 
Chkfind = Big_str.find(Sub_str)
Chkfind 
# Find Returns index pos else returns -1 

# Let us try the index command now 
ChkInd = Big_str.index(Sub_str)
ChkInd

# Now check for a string not present 
ChkInd = Big_str.index(Sub_str)
ChkInd


# Count the number of occurence of a substring in main string 
Chkcnt = Big_str.count(Sub_str)
Chkcnt

#--------------------------------------------------------------------------
# Regular Expressions 
#--------------------------------------------------------------------------
# Example 1: Splitting s atring with variable white space
# regex is '\s+'  
#--------------------------------------------------------------------------
import re 
text1 = " We have a    Lot \t    of white space here   "
split_text1 = re.split('\s+',text1)
split_text1


#------------------------------------------------------------------------
# Example 2:   reg ex on email id types 
#------------------------------------------------------------------------
text2 = """Dave dave@google.com
Steve steve@gmail.com
Rob rob@gmail.com
Ryan ryan@yahoo.com
"""

# Notes:   findall returns ALL matches in a string 
# Notes    search returns ONLY the first match 

# Define Pattern 
# r' '   means raw string 
# [A-Z0-9._%+-] means A to Z , 0 to 9 and special chars 
# [A-Z]{2,4}  Alphabets length between 2 to 4 
pattern = r'[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}'

# Compile pattern after ignoring case 
regex = re.compile(pattern, flags=re.IGNORECASE)

# Find All email addresses in text 
List_EMails = regex.findall(text2) 
List_EMails

# Search command
List_EMails_Breakup = regex.search(text2) 
List_EMails_Breakup

# Note:  The Search command only returns the first occurence 
#        The  start end positions     of the reg ex string 

# Substitute a Reg Ex With any other string : Use this for masking 
Masked_Emails = regex.sub('Masked_Email', text2)


# Dividing The email ids in user names ; domain name ; domain suffix
pattern1 = r'([A-Z0-9._%+-]+)@([A-Z0-9.-]+)\.([A-Z]{2,4})'

# Compile pattern after ignoring case 
regex = re.compile(pattern1, flags=re.IGNORECASE)

List_break_up =   regex.findall(text2)
List_break_up

# Generate a named list of the break of email ids 
regex = re.compile(r'(?P<username>[A-Z0-9._%+-]+)@(?P<domain>[A-Z0-9.-]+)\.(?P<suffix>[A-Z]{2,4})',flags=re.IGNORECASE) 
Break_namedlist = regex.findall(text2)
Break_namedlist 

match_namedlist = regex.match('abc@xyz.com')
match_namedlist 
match_namedlist.groupdict()

#--------------------------------------------------------
# Vectorizing string functions in pandas 
#--------------------------------------------------------
import pandas as pd 
import numpy as np 

# Consider the series
 s1 = pd.Series(['A', 'B', 'C', 'Aaba', 'Baca',  'CABA', 'dog', 'cat'])

# Let us try converting it to lower case 
s1_lower = s1.lower()


# Oops : let us try again with the str.lower function 
s1_lower = s1.str.lower()
s1_lower 

# Let us now define a Series with one object being a NAN 

s2 =  pd.Series(['A', 'B', 'C', 'Aaba', np.NaN,  'CABA', 'dog', 'cat'])
# convert to lower case 

s2_lower = s2.str.lower()
s2_lower

# finding length of each member of the series 
s2_len = s2.str.len()
s2_len

#-------------- END of  MODULE ---------------------------------
#---------------------------------------------------------------
# Please install:   pip install simplejson 
#---------------------------------------------------------------
import json
import pandas as pd 

# READ FILE In JSON Format 

#USDA = pd.read_table('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_9/USDA.txt')
USDA_DB = json.load(open('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_9/USDA.txt'))
# Check to see the DB is a Dict object 
type(USDA_DB)

# Let us start Drilling Down in this Nested Dictionary Structure 
# NOTE OUTER LEVEL is RECORD : We Have  Only One Record - Check 
len(USDA_DB)

# get the Key List for the Outer Level 
USDA_DB.keys()

# Now Access the Keys in the Second Level 
USDA_DB['report'].keys()
# Let us display the Keys of this Dict Object 
# Note : --   'foods' is the key we are interested in 
# Now Let us Access the entries under the  Sub Key 'foods' 

food_list = USDA_DB['report']['foods']
# Check TYpe 
type(food_list)

# Note At this point We have reached a List of Food Items Each member in the list is a dict.
# Thus We have a list of dicts.

# Check  :  Find the keys of the  first element of the food list 
First_Elem_keys = food_list[0].keys()
First_Elem_keys

#--------------------------------------------------------
# Pre liminary Analysis on the food types 
#-------------------------------------------------------
#Let us Extract a DataFrame of the food names and nbdno
Xtract_Key = ['name','ndbno']
FoodDF = DataFrame(food_list,columns=Xtract_Key)
# Check first Five Rows of the Food data Frame 
FoodDF.head()

#-------------------------------------------------------
#  Analysis on Nutrient Data 
#------------------------------------------------------
 # Let us examine the structure once more
 
 NutrientDF = []
 for item in food_list:
     NutDF = DataFrame(item['nutrients'])
     NutrientDF.append(NutDF)
#--------------------------------
NutrientDF = pd.concat(NutrientDF, ignore_index=True)
#-----------
NutrientDF = NutrientDF.drop_duplicates(subset='nutrient_id')
NutrientDF

#---------------------------------------------------------------------------
#  What we Really Want ???
#  We want A food  associated with its Nutrient 
#  We want the data in a tabular format for easy query access 
#  Thus:
#  We want to assemble the nutrients for each food in a large table
#
#--------------------------------------------------------------------------
# Key Steps 
# Loop through all Foods 
# Extract Nutrients for a particular Food And convert that list to a dataframe
# Add a column for food id 
# Append to a list 
# Concat
# --------------------------
# Test Loop Through all food items 
i = 1
for item in food_list:
    print(i)
    i = i+ 1
#  Note we find that we have 150 food items in total 
#-------------------------------
# Test the set of nutrients    for each food item 
Nutri_DF = []
for foods in food_list:
    Nutri_DF = DataFrame(foods['nutrients'])
    print(Nutri_DF)
#----------------------------------------------------    
# Check the DF structure for the last food item ; compare with above 
DataFrame(food_list[149]['nutrients'])    

#--------------------------------------------------------------------------------
# Now extract the ndbno for each food item and Append it to the DF for nutrients
#--------------------------------------------------------------------------------
Nutri_DF = []
for foods in food_list:
    Nutri_DF = DataFrame(foods['nutrients'])
    Nutri_DF['ndbno'] = foods['ndbno']
    print(Nutri_DF)
#----------------------------------------------------------------------------
# Now we will concatenate the DF's for all the food items 
#---------------------------------------------------------------------------
Nutri_DF = []
All_Nutri_DF = []
for foods in food_list:
    Nutri_DF = DataFrame(foods['nutrients'])
    Nutri_DF['ndbno'] = foods['ndbno']
    All_Nutri_DF.append(Nutri_DF)
print(All_Nutri_DF)   
#----------------------------------------------------------------------------
# Now Observe the following    
#----------------------------------------------------------------------------
# We now have a list - Each item of which is a DataFrame
# We now need to concatenate all of the items into one single DataFrame
#--------------------------------------------------------------------------
Nutri_DF = []
All_Nutri_DF = []
for foods in food_list:
    Nutri_DF = DataFrame(foods['nutrients'])
    Nutri_DF['ndbno'] = foods['ndbno']
    All_Nutri_DF.append(Nutri_DF)
#----
All_Nutri_DF = pd.concat(All_Nutri_DF, ignore_index=True)
print(All_Nutri_DF)

#----------------------------------------------------------------------------
# Note:  Now we have a DataFrame  with entries for all nutrients 
#        Additional column of the corresponding FoodID is also included  
#----------------------------------------------------------------------------
# Let us check if we have any duplicates in this DataFrame 
#----------------------------------------------------------------------------
All_Nutri_DF.duplicated().sum()
# Note that the count of duplicates is zero 

# Let us now Re Create the DataFrame for food items !
Xtract_Key = ['name','ndbno']
FoodDF = DataFrame(food_list,columns=Xtract_Key)

#-----------------------------------------------------
# Let us now merge the DataFrames on the 'ndbno' 
#-----------------------------------------------------
Combo_DF = pd.merge(FoodDF,All_Nutri_DF, on='ndbno', how='outer')
Combo_DF

#-------------------------------------------------------
# Let us Write this out to a csv file  for further analysis 
#-------------------------------------------------------

# Use to_csv()  command to write out data - default is comma separated 
Combo_DF.to_csv('C:/Users/roychowa/Desktop/HP_Python_Workshop/Module_9/FoodData.csv')


#    End of This Module 
