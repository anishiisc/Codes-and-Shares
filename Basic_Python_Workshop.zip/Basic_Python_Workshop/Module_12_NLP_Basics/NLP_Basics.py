# -*- coding: utf-8 -*-
###################################################################################
#  INTRODUCTION to NLP 
############################################ Step-1- Import Libraries #####################################
import nltk
#nltk.download()
import urllib3
from pandas import * 
# Import all books in nltk package 
from nltk.book import *
# Check list of books 
#texts()

# Word Search 
# Search for  the word "Monstrous" occurs in Moby Dick 
text1.concordance("monstrous")
# Search for words used in similar context 
text1.similar("monstrous")

# Search for common contexts shared by two words
text2.common_contexts(["monstrous","very"])

# Dispersion plot - Where does a text occur 
text4.dispersion_plot(["citizens", "democracy", "freedom", "duties", "America"])


#Counting 
# How many words in the book 3  ?
len(text3)

# Get the set of vocabulary in a sorted fashion for book 3
sorted(set(text3))

# find measure of richness 
from __future__ import division
len(text3) / len(set(text3))
# Notes : We find on an avg each word is used 16 times

# How many times a particular word  has occured?
text1.count("Moby")

# What percentage of times a word occurs in a text 
100*text2.count("very")/len(text2)


# define function for lexical richness 
def lexical_diversity(text):
    return len(text)/len(set(text))

#define function for  percentage of a words occurence 
def perc_occur(text,str1):
     return 100*text.count(str1)/len(text) 
#------------------------------------------------------------ 
# Let us use these functions 
#---------------------------     
# test richness of text 3 
lexical_diversity(text3)     

# test word perc of word "very" in text 1
perc_occur(text1,"very")
#--------------------------------------------------------
#     text as list of words 
#-------------------------------------------------------
# Create a list of words 
wordlist = ['Call', 'me', 'Ishmael', '.']

#check length 
len(wordlist)


lexical_diversity(wordlist)

# Special word selection Using Sets and conditions
# Create master words set 
V = set(text1)
# Choose only long words 
long_words = [w for w in V if len(w) > 15]
sorted(long_words)

# Collocations 
# Extracting words occuring together 
text4.collocations()
#-------------------------------
# Convert a Freq Table to a Data Frame 
#--------------------------------
list1 = [1,2,1,2,2,2,2,2,2,3,4,5,5]
list1
# 
FTable = FreqDist(list1)
FTable.keys()
FreqDF = DataFrame.from_dict(FTable, orient='index').reset_index()
FreqDF

FreqDF.columns = ['column_one', 'column_two']
FreqDF

#-------------------------------------------------------------
# Playing with strings 
#---------------------------------------------------------------
name = 'Monty'
title = 'Python'
# Get first char of name 
name[0]
# Add or Multiply a string 
twotimes_name = name*2
twotimes_name
#
fullname = name + title
fullname
# Create a List  with name and title
namelist = [name,title]
namelist 

# Join words of a list to make a singel string 
nameString = ''.join(namelist)
nameString
# Now include a gap between the words
nameString1 = ' '.join(namelist)
nameString1

## Now split  a long string into list elements separated at delim 
namelist1 = nameString1.split()
namelist1

#-----------------------------------------------------------------------
#   Raw  Text Handling 
#-----------------------------------------------------------------------
# Access Raw Text from a web url 
#-----------------------------------------------------------------------
http = urllib3.PoolManager()
r = http.request('GET', 'https://www.gutenberg.org/files/236/236-0.txt')
# Check Status 200 means  read success
r.status
# Get Raw data 
raw = r.data
type(raw)
# Note that the data type is bytes:
# Note we have to convert this to string for further processing 
#---------------------------------------------------
len(raw)
# Display the first 80 bytes of the Raw text
raw[:80]
# -   We now convert the byte object to string 
str1 = raw.decode("utf8")
# check that the objecttype is now string 
type(str1)
#------------------------------------------------------------------------------
#   CLeaning up the data - Tokenization 
#-----------------------------------------------------------------------------
from nltk import word_tokenize
tokens =    nltk.word_tokenize(str1)
# Check output is a list 
type(tokens)
# Display 
print(tokens)
#----------------------------------------------------------
# Now convert tokens to nltk.Text for further processing 
#---------------------------------------------------------
text = nltk.Text(tokens)
type(text)
#-------------------------------------------------------------------------
#    End of Processing Raw text from Web 
#--------------------------------------------------------------------------

# ----------------------------------------------------------------------
#  Reading html data : Notes : Use beautiful Soup for better handling
#  HTML reading is better covered in the Webscraping module 
# Beautiful Soup is the preferred tool used for html handling 
#-----------------------------------------------------------------------

#---------------------------------------------------------------------
#----------   REGULAR EXPRESSIONS FOR FINDING WORD PATTERNS 
#---------------------------------------------------------------------
import re 
# We use the nltk inbuilt word corpus 
wordlist = [w for w in nltk.corpus.words.words('en') if w.islower()]

#--------  Simple Regular   Expression Exercises -------------------------------------
#--------------------------------------------------
#  Find words ending in ed   Reg Ex is ed$   
#  Note $ symbol matches 'end of the word ' 
#----
[w for w in wordlist if re.search('ed$', w)]
#--------------------------------------------------
#   Cross Word puzzle cracker 
#    find words which are:   Eight letter in length 
#                             have 'j' as its third letter 
#                              and 't' as its sixth  letter 
#---
[w for w in wordlist if re.search('^..j..t..$',w)]
#-----
# Note: 
#          '^'  stands for start of string 
#          '.'  is the wildcard for a single character  
#--------------------------------------------------------------
# Find words email or e-mail  and count how many time they occur 
#---
[w for w in wordlist if re.search('^e-?mail$',w)]
#-
sum([1 for w in wordlist if re.search('^e-?mail$',w)])
#---
# Note in this case no matches found hence count is zero 
#-
#---------------------------------------------------------
# Searching for textonyms - Words typed from Keypad cell phones 
#----------------------------------------------------------------
#  Key pad layout is shown below 
#  1         2 ABC    3 DEF 
#  4  GHI    5 JKL    6 MNO 
#  7  PQRS   8 TUV    9 WXYZ
#---------------------------------------------------------------
# Find words with key sequence 4653 
#---
[w for w in wordlist if re.search('^[ghi][mno][jkl][def]$',w)]
# Notes 
#  [ghi] means either of 'g' or 'h' or  'i' 
#--------------------------------------------------------------
#  Search for patterns or specific chat words 
#--------------------------------------------------------------
chat_words = sorted(set(w for w in nltk.corpus.nps_chat.words()))
# search  for all patterns for the word mine 
[w for w in chat_words if re.search('^m+i+n+e+$',w)]
# Notes:   
#   the '+'  symbol allow for one or multiple occurences of the preceding character 
#----------------------------------------------------------------
#  search for chat words with partial or full occurence of characters in 'mine'
#--
[w for w in chat_words if re.search('^m*i*n*e*$',w)]
#----
# Notes   
# '*' allows zero or more coccurences of preceding character 
#----------
# Search for words with NO Vowels 
#--------------------------------
[w for w in chat_words if re.search('^[^aeiouAEIOU]+$',w)]
#--------------------------------
# Notes 
# the '^' operator inside a []  behaves like an exclusion operator 
#--------

#---------------------------------------------------------------------------
#----------------- DETAILS of OPERATORS in REG EXP
#---------------------------------------------------------------------------
# Operator            Behavior
# .                   Wildcard, matches any character
# ^abc                Matches some pattern abc at the start of a string
# abc$                Matches some pattern abc at the end of a string
# [abc]               Matches one of a set of characters
# [A-Z0-9]            Matches one of a range of characters
# ed|ing|s            Matches one of the specified strings (disjunction)
# *                   Zero or more of previous item, e.g., a*, [a-z]* (also known as Kleene Closure)
# +                   One or more of previous item, e.g., a+, [a-z]+
# ?                   Zero or one of the previous item (i.e., optional), e.g., a?, [a-z]?
# {n}                 Exactly n repeats where n is a non-negative integer
# {n,}                At least n repeats
# {,n}                No more than n repeats
# {m,n}               At least m and no more than n repeats
# a(b|c)+             Parentheses that indicate the scope of the operators
#---------------------------------------------------------------------------------

#  Extracting word pieces
#  - --
#  Example:  count the number of vowels in a particular word
# ------ 
word = 'supercalifragilisticexpialidocious'
len(re.findall(r'[aeiou]', word))

#--------------------------------------------------------------------------------
#  WORD STEMS,   Example   'surf'  and 'surfing'   can be extracted by searching for 'surf'
#  Function to STEM a word   for some pre decided list of suffix 
#--------------------------------------------------------------------------------
def stem(word):
  for suffix in ['ing', 'ly', 'ed', 'ious', 'ies', 'ive', 'es', 's', 'ment']:
      if word.endswith(suffix):
         return word[:-len(suffix)]
  return word
#--------------------------------------------
word1  = 'surfing' 
word2  =  'motive' 
word3  = 'movement'
word4  = 'managing'
#--------------------------------------------
word1_stemmed =   stem(word1)
print(word1_stemmed)
#-------------------------------------------
word2_stemmed = stem(word2)
print(word2_stemmed)
#------------------------------------------
word3_stemmed = stem(word3)
print(word3_stemmed)
#------------------------------------------
word4_stemmed = stem(word4)
print(word4_stemmed)
#-------------------------------------------
# Notes:   Sometimes stemming a word might make it lose its meaning as well 
# ------------------------------------------
from nltk.corpus import gutenberg, nps_chat
moby = nltk.Text(gutenberg.words('melville-moby_dick.txt'))
len(moby)
type(moby)

#-------------
#  Searching tokenized text 
#--------------
# Example 1:   phrase from a Classic 
#--------------------------------------
# Let us find for all words which come in the form 'a wordofinterest man'
# Here our objective is to search for a word which describes 'a man'  and hence we search 
# With the following token sequence      <a> (<.*>) <man>
#  The ()  signifies only the matched word will be returned and not the whole phrase 
#------------------------------------------------------------
moby.findall (r"<a> (<.*>) <man> ")
#-------------------------
# Example 2 : chat phrase 
#-------------------------
# Let us now try to capture entire phrase of three words ending with 'bro'
#----
# Get the chat corpus of words inbuilt in nltk 
chat = nltk.Text(nps_chat.words())
# Search for  token pattern 
chat.findall(r"<.*> <.*> <bro>")

#--------------------------------------------------------------------------
#  Normalizing text 
#--------------------------------------------------------------------------
# Consider the raw text below 
#
raw = """DENNIS: Listen, strange women lying in ponds distributing swords
... is no basis for a system of government. Supreme executive power derives from
... a mandate from the masses, not from some farcical aquatic ceremony."""
#
# display as is 
print(raw)

#--------------------------------------------
#  Tokenize 
tokens = nltk.word_tokenize(raw)
print(tokens)

#--------------------------------------------
#  Convert all to lower case 
tokens = list(w.lower() for   w in tokens)
type(tokens)
print(tokens)
#-------------------------------------------
#    Stem using off the shelf stemmers
#-------------------------------------------
porter = nltk.PorterStemmer()
lancaster = nltk.LancasterStemmer()
#-----------
# Let us see how the 'porter' stemmer works 
#----------
[porter.stem(t) for t in tokens]
#--------------
# Now see how the lancaster stemmer works 
#--------------
[lancaster.stem(t) for t in tokens]

#-----------------------------------------------------------------------
# Notes:  Observe the difference between how the words
#         'lying' and 'women' are handled by the two different stemmers
#----------------------------------------------------------------------

#--------------------------------------------------
#   Lemmatize   with Wordnet 
#------------------------------
# Notes 
#  WordNet lemmatizer removes affixes only if
# the resulting word is in its dictionary
#------------------------------------------
wnl = nltk.WordNetLemmatizer()
[wnl.lemmatize(t) for t in tokens]
#-------------------------------------------------------
# Notes:  -    See how the word women --> becomes woman 
#-------------------
# Segmentation ; Dividing corpus into sentence segements 
# Notes: All corpora do not allow sentence segementation 
# We are using the  Brown Corpus 
#----------------------------------------------------------
# What is the  Average number of words used per sentence ?
len(nltk.corpus.brown.words()) / len(nltk.corpus.brown.sents())

# Notes  : sometimes the text is available as continuous stream 
#         In that case one needs to segment words into sentences 
#----------------------------------------------------------
text = nltk.corpus.gutenberg.raw('chesterton-thursday.txt')
type(text)
# Note in this case the data is a large string and not demarcated into sentences 
print(text)

# We use the Punckt sentence segmenter 
# Load Punckt 

sent_tokenizer=nltk.data.load('tokenizers/punkt/english.pickle')
sents = sent_tokenizer.tokenize(text)
type(sents)
# Note Now we have a list of Sentences 
# Let us print the first 5 list elements 
sents[0:4]

#-----------------------------------------------------------------------------
#    Writing formatted Output 
#----------------------------------------------------------------------------
# Example: Display in a formatted the way the Freq Dist Table for the  list of 
#          animals below 
#------------------------------------------------------------------------
animals = ['dog','cat','dog','cat','dog','snake','snake','cat']
Anim_Freq = nltk.FreqDist(animals)
# Note :  Chek out how the Freq DIst output is 
Anim_Freq
# Note We can now iterate through the keys of this dict and format output accordingly
for word in Anim_Freq:
    print (word,'->',Anim_Freq[word],';')
#-----------------------------------------------------------------------
#    End of Module 
#-----------------------------------------------------------------------    





