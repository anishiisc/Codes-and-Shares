# --
# Python Module 8 :  Data Manipulation 
# -------------------------------
from pandas import *
from numpy import *
from scipy import *
import re 
#----------------------------------------------------------------------
# Data Set Merging With one or more keys : Def is Inner Join 
#---------------------------------------------=------------------------
# create DF1

df1 = DataFrame({'key': ['b', 'b', 'a', 'c', 'a', 'a', 'b'],
     'data1': range(7)})
df1

# Create DF2
df2 = DataFrame({'key': ['a', 'b', 'd','a'],
     'data2': range(4)})

df2

# Many to Many Merge 
merged_df = merge(df1,df2,on='key') 
merged_df

#--------------------------------------------------------
# Key Col names are different : def is inner Join 
#-----------------------------------------------------
df3 = DataFrame({'Leftkey': ['b', 'b', 'a', 'c', 'a', 'a', 'b'],
     'data1': range(7)})
df3

# Create DF2
df4 = DataFrame({'Rightkey': ['a', 'b', 'd','a'],
     'data2': range(4)})
df4

merged_dfnew = merge(df3,df4,left_on='Leftkey',right_on ='Rightkey') 

merged_dfnew
#-------------------------------------------------------------------------
# Outer Join example 
#-------------------------------------------------------------------------

merged_Outer = merge(df1,df2,how='outer')
merged_Outer

#----------------------------------------------------------------------------
# Merge in Index
#--------------------------------------------------------------------------
LeftDF= DataFrame({'key': ['a', 'b', 'a', 'a', 'b', 'c'],
 'value': range(6)})
LeftDF


RightDF = DataFrame({'group_val': [3.5, 7]}, index=['a', 'b'])
RightDF 

Merged_Ind = merge(LeftDF,RightDF,left_on='key', right_index=True)
Merged_Ind

#---------------------------------------------------------------------------
#  Concat Array side by side with alternate axis 
#------------------------------------
Arr1 = np.arange(12).reshape((3, 4))
Arr_Stack = concatenate([Arr1, Arr1], axis=1)
Arr_Stack

#----------------------------------------------------------------------
#  Concat Series : default is Axis = 0 
#---------------------------------------------------------------------
S1 = Series([0, 1], index=['a', 'b'])
S2 = Series([3, 4], index=['c', 'd'])
S3 = Series([5, 9], index=['e', 'f'])

Merged_Ser = concat([S1, S2, S3])
Merged_Ser 
#----------------------------------------------------------------------
#  Concat Series : Axis = 1  Will convert to Dataframe 
#--------------------------------------------------------------------
Merged_Axis1 = concat([S1, S2, S3], axis=1)
Merged_Axis1

#-----------------------------------------------------------------------
#  Removing Duplicates 
#-----------------------------------------------------------------------
# Create DF with Dups

DupDF = DataFrame({'k1': ['one'] * 3 + ['two'] * 4,
                  'k2': [1, 1, 2, 3, 3, 4, 4]})

DupDF

# Check if Each row is duplicated row or not 
DupDF.duplicated()

# Remove Duplicate Rows 
NoDup = DupDF.drop_duplicates()
NoDup

# Create Additional Column 
DupDF['NewCOl'] = range(7)
DupDF

# Now Drop duplicates based on values in first col only 
NoDup1 = DupDF.drop_duplicates(['k1'])
NoDup1


# Advanced : map function like a Vlook up 
#0-------------------------------

#----------------------------------------------------------
#  Replace missing values 
DF1data = Series([1., -999., 2., -999., -1000., 3.])
DF1data


# Replace -999  with NA's 
DF2data = DF1data.replace(-999, np.nan)
DF2data
# replace a set of values with other values 

#----------------------------------------------------------------
# Discretization and  binning 
#--------------------------------------------------------------- 
# Create Input Set 
Ser1 = [20, 22, 25, 27, 21, 23, 37, 31, 61, 45, 41, 32]
# Define bin ranges  
Ser1_bins = [18,25,35,65,100]

# Allocate data to bins 
Ser1_Binned = cut(Ser1,Ser1_bins)

# Check data type : will be categorical 
type(Ser1_Binned)

# Generate Frequency table : Type is Series 
Ser1_freq = value_counts(Ser1_Binned)
Ser1_ind = Ser1_freq.index

# Create Data frame with Freq Table Information 
Freq_Table_DF = DataFrame({'Bin':Ser1_freq.index, 'Count':Ser1_freq.values})
Freq_Table_DF

# Change Bin Names to meaningful ones 
bin_names = ['Youth', 'Young Adult', 'Middle Age', 'Senior Citizen']
Ser2_Binned = cut(Ser1,Ser1_bins,labels= bin_names)
Ser2_freq = value_counts(Ser2_Binned)
Ser2_ind = Ser2_freq.index
Freq_Table_DF_Named = DataFrame({'Bin':Ser2_freq.index, 'Count':Ser2_freq.values})
# Display 
Freq_Table_DF_Named
#-----------------------------------------------------------
# Detecting and Filtering Outliers 
#-----------------------------------------------------------
# Set Seed
random.seed(123) 
# Create a Dataframe of dimension 4 COlumns having 1000 rows of random values each 
DF1 = DataFrame(random.randn(1000,4))
DF1

# Capture all rows which  has abs value greater than 3 
DF1_GT3 = DF1[(abs(DF1)>3).any(1)]
DF1_GT3

#----------------------------------------------------------
# Permutation and Random Sampling 
#---------------------------------------------------------
#Create a  data Frame -  5 Rows For Columns 
DF1 = DataFrame(arange(5*4).reshape(5,4))
DF1
# Create a Random Permutation of Row Length 
Sequence1 = random.permutation(5)
Sequence1
#  Change DataFrame Row Positions per sequence
DF2 = DF1.take(Sequence1)
DF2
#-----------------------------------------------------




#----------------------------------------------------------
# Dummy Variable Creation to  Handle category Type Data 
# ----------------------------------------------------------
# Create a Column of Categorical Data 

DF1 = DataFrame({'key': ['b', 'b', 'a', 'c', 'a', 'b'],
                 'data1': range(6)})
DF1
# Note that the Col <key> has categorical data 
#Now we create dummy columns  for the categorical data 

DummyDF = get_dummies(DF1['key'])
DummyDF


# --------------------    END   of MODULE ---------------------------------------