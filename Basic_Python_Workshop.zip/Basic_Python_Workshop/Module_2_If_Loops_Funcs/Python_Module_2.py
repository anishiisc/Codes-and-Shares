# MODULE 2 Python 
# Decisions 
# If statements 
# One Line if statements 
var = 100
if (var  == 100) : print ("Value of expression is 100"  )

# if else 
var1=100; var2 = 110
if (var2 == var1): 
    print ("Values match ")
else:
    print ("Values Do not Match")

# Nested if else     

var = 199
if var < 200:
   print ("Expression value is less than 200")
   if var == 150:
      print ("Value is 150")
   elif var == 100:
      print ("Value is 100")
   elif var == 50:
      print ("Value is 50")
elif var > 150:
   print ("Expression value is > than 150")
else:
   print ("Value is = 200 ")

#-------------------------------------
# loops
#-------
# While Loops 
count = 0
while (count < 5):
   print ('The count is:', count)
   count = count+1
   
# for loops
for i in 'Python':     # First Example
   print ('Current Letter :', i)
   

   
fruits = ['banana', 'apple',  'mango']
for abc in fruits:        # Second Example
   print ('Current fruit :', abc)
 

# iterate by index sequencing    
fruits = ['banana', 'apple',  'mango']
for index in range(len(fruits)):
   print ('Current fruit :', fruits[index])
   
#---

# Break statement 
var = 10                    
while var > 0:              
   print ('Current variable value :', var)
   var = var -1
   if var == 5:
      break
print ("This Line is outside the loop!")
   

# Continue statement
for letter in 'Python':     
   if letter == 'h':
      continue
   print ('Current Letter :', letter)


# Pass statement 
for letter in 'Python': 
   if letter == 'h':
      pass
      print ('This is pass block')
   print ('Current Letter :', letter)

print ("Good bye!")

#---------------------------------------------------------------------------
#-                       Inbuilt Math Functions 
#---------------------------------------------------------------------------
# abs(x)
print ("abs(-45) : ", abs(-45))


# ceil(x)
import math   # This will import math module

print ("math.ceil(-40.17) : ", math.ceil(-40.17))
print ("math.ceil(100.12) : ", math.ceil(100.12))
print ("math.ceil(100.72) : ", math.ceil(100.72))


# floor (x)
import math   # This will import math module

print ("math.floor(-40.17) : ", math.floor(-40.17))
print ("math.floor(100.12) : ", math.floor(100.12))
print ("math.floor(100.72) : ", math.floor(100.72))

# exponential 
import math 
print ("math.exp(-45.17) : ", math.exp(-45.17))
print ("math.exp(100.12) : ", math.exp(100.12))



# log 
import math 
print ("math.log(100) : ", math.log(100))
print ("math.log10(100) : ", math.log10(100))

# extrema 
print ("max(80, 100, 1000) : ", max(80, 100, 1000))
print ("min(-20, 100, 400) : ", min(-20, 100, 400))


import math   # This will import math module

print ("math.pow(100, 2): ", math.pow(100, 2))
print ("math.pow(100, -2) : ", math.pow(100, -2))

#--------------------------------------------------------------
# User Defined Functions 
# Example of function  - Simple example 
#------------------------------------------
# Function to print name and age 
#-----------------------------------------
# Function definition is here
def printinfo( name, age ):
   "This prints a passed info into this function"
   print ("Name: ", name)
   print ("Age ", age)
   return;

# Now you can call printinfo function
printinfo( age=50, name="Roy" )
printinfo(50,"Roy")

#---------------------------------------------------------------
#--
# Example of pass by Reference Function 
def changeme( mylist ):
   "This changes a passed list into this function"
   mylist.append([1,2,3,4]);
   print ("Values inside the function: ", mylist)
   return

# Now you can call changeme function
mylist = [10,20,30];
changeme( mylist );
print ("Values outside the function: ", mylist)


#---------------------------------------------------------
#  Example of Variable Length Function 
#---------------------------------------------------------

# Function definition is here
def printinfo( arg1, *vararg ):
   "This prints a variable passed arguments"
   print ("Output is: ")
   print (arg1)
   print(type(vararg))
   for var in vararg:
      print (var)
   return;

# Now you can call printinfo function
printinfo( 10 )
printinfo( 20, 30, 40 )

#--------------------------------------------------
# Example of function having arguement as another function 

from math import sin, cos

# function definition
def first_deriv(f,x,h=0.001):
    deriv =(f(x+h) - f(x-h))/(2.0*h)
    return deriv

x = 0.5
# Compute First derivative of sin(x)
Df_sin = first_deriv(sin,x)
# Display value of computed derivative
print("Computed deriv of sin(0.5) = ", Df_sin)
# Display value of cos(x)
print("\n Actual value of   cos(0.5) = ", cos(0.5)) 
