# MODULE 3 Python 
# Strings
#--------------------------------------------
# special string operators 
#-----------------------------------------------
# Concatenation 

Str1 = "Hello"
Str2 = "World"

Str3 = Str1 + " " + Str2
print("Str3 = Str1 + Str2 = ", Str3)

# Repetitiion 
Str1 = "ABC"
Str2 = Str1*3
print("Str2 = Str1*3  = ",Str2)

# Some built in String Methods 

# Count of subtring in a given string 
str = "this is string example";
sub = "is";
print ("str.count(sub, 0, 40) : ", str.count(sub,0,40))

# Find - returns index pos of sub string in parent string 

str1 = "this is string example";
str2 = "exam";

print (str1.find(str2))
print (str1.find(str2, 10,len(str1)))
print (str1.find(str2, 40,len(str1)))

# Alphabetic check 
str1 = "this";  # No space & digit in this string
print (str1.isalpha())

str2 = "this is string example....wow!!!";
print (str2.isalpha())


# digit check
str1 = "123456";  # Only digit in this string
print (str1.isdigit())

str2 = "this is string example....wow!!!";
print (str2.isdigit())


#lower case check 
str1 = "THIS is string example....wow!!!"; 
print (str1.islower())

str2 = "this is string example....wow!!!";
print (str2.islower())


# convert to lower
str1 = "THIS IS STRING example";
print (str1.lower())


# Stripping  trailing white space 
str1 = "XXXXXthis is string example....wow!!!     ";
print(len(str1))
print(len(str1.lstrip()))

print (str1.rstrip())

#Stripping leading character
str2 = "88888888this is string example....wow!!!8888888";
print (str2.lstrip('8'))



#  Replace old string with new 
str = "this is a string"
print (str.replace("is", "was"))
print (str.replace("is", "was", 1))


# Splitting strings 
str = "Line1-abcdef  Line2-abc Line3-abcd";
print (str.split( ))
print (str.split(' ', 1 )) # One split 


# Translate Table
intab = "aeiou"
outtab = "12345"
str1 = "this is string example....wow!!!"
str2 = str1.translate(str.maketrans(intab,outtab))
print("Before Change String is : ",str1)
print("After Change String is : ",str2)

#---------------------------------------------------------------------------
#-                         Lists 
#----------------------------------------------------------------------------

list1 = ['ABCD', 'XYZ', 1234, 9999];
list2 = [1, 2, 3, 4, 5, 6, 7 ];

# Accessing list items 
print ("list1[0]: ", list1[0])
print ("list2[1:5]: ", list2[1:5])

#--------------------------------------------------------------
# Basic List Operations 
# Similar to Strings 
#--------------------------------------------------------------
list1 = [1,2,5]
list2 = [3,4,5]
# Length
len1 = len(list1)
print("length = ",len1)

#Concatenation 
list3 =   list1 + list2
print("Concat List is : ",list3)

# Repetition 
list4 = 4*list1
print("Repetitive list =: ",list4)

# Membership 
if(3 in list2):
    print("list 2 = ",list2)
    print("3 is a member of list2")
else:
    print("3 is not a member of list2")     

# Iteration 
for x in [1, 2, 3]:
    print(x)
    
#--------------------------------------------------------------
# Built in list methods 
#--------------------------------------------------------------
# Appending elements to a list 
#-------------------------------------
list1 = [123, 'xyz', 'pqr', 'abc']
print("List before Append",list1)
list1.append([1,2,3,4])
print("List after Append",list1)
print(list1)
        
#-------------------------------------------------------
#  Count of particular elements in a list 
#-------------------------------------------------------
list1 = [123, 'xyz', '999', 'abc', 123];
print ("Count for 123 : ", list1.count(123))
print ("Count for xyz : ", list1.count('xyz'))

#-------------------------------------------------------
# Extend a list 
#------------------------------------------------------
Primary_List = [123, 'xyz', 'zara', 'abc', 123]
Secondary_List = [2009, 'manni']
print("Primary List - Original: ",Primary_List)
Primary_List.extend(Secondary_List)
print("Extended Primary List : ", Primary_List)

#---------------------------------------------------------
# Index of object in a list 
#---------------------------------------------------------
list1 = [123, 'xyz', 'pqr', 'abc',456];
print ("Index for xyz : ", list1.index('xyz')) 
print ("Index for 123 : ", list1.index(123))
print(list1[-2])
#---------------------------------------------------------
# Insert at Index position 
#---------------------------------------------------------
list1 = [123, 'xyz', 'pqr', 'abc']
print("Original list is : ",list1)
list1.insert(1, "ZZZ")
print("Modified list is: ",list1)

#-----------------------------------------------------------
#  Removes object from a list 
#----------------------------------------------------------
list1 = [123, 'xyz', 'pqr', 'abc', 'xyz'];
set1 = set(list1)
print(set1)
print([set1])
print("Original list: ",list1)
list1.remove('xyz');
print("List after modification: ",list1)

#---------------------------------------------------------
#  Reverse Objects from a list 
#----------------------------------------------------------
list1 = [123, 456, 789, 'abc', 'xyz']
print("List before reverse", list1)
list1.reverse();
print("List after reverse",list1)


#---------------------------------------------------------
#  Sort elements of a list 
#--------------------------------------------------------
list1 = [456,999,234,123]
print("List before sort",list1)
list1.sort()
print("list after sort ",list1)

#  Hwo to Sort in Reverse 
#---------------------------------------------------
#   Tuples : Cannot be  modified unline lists 
#-----------------------------------------------------
tup1 = ('physics', 'chemistry', 1997, 2000);
tup2 = (1, 2, 3, 4, 5 );
tup3 = ("a", "b", "c", "d")

# Cannot be modified 
tup3[1] = "x"

#-------------------------------------------------------
#   Date Time Important Functions 
#--------------------------------------------------------
# Local time 
#-------------------------------------------------------
import time;

localtime = time.localtime(time.time())
print ("Local current time :", localtime)


#---------------------------------------------------
# asctime()  Formatted Local time 
# Converts a Time Tuple into a 24 char format 
#---------------------------------------------------
import time;
localtime = time.asctime(time.localtime(time.time()))
print ("Formatted Local current time :", localtime)
#-----------------------------------------------------
#  Getting the CPU Time to measure computational costs
#-----------------------------------------------------
import time
def procedure():
    time.sleep(2.5)
# measure process time
t0 = time.clock()
print (time.clock(), "Before Process ")
procedure()
print (time.clock(), "After Process ")
#--------------------------------------------------
#  Calendar Module Examples 
#--------------------------------------------------
# Print calendar for a  particular month 
import calendar
cal = calendar.month(2017, 9)
print ("Here is the calendar: for 2017 September")
print (cal)


# Leap year check 
if(calendar.isleap(2016)):
    print("2016 is a leap year ")
else:
    print ("2016 is NOT a leap year")    
	
    
#----------------------------------------------------------------    